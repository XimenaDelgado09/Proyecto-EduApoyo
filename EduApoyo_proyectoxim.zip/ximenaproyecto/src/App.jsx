import { Routes, Route } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import Login from "./pages/Login";
import QuienesSomos from "./pages/QuienesSomos";
import Terminos from "./pages/terminos";
import Condiciones from "./pages/Condiciones";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import "./App.css";

export const App = () => (
  <Routes>
    <Route path="/" element={<LandingPage />} />
    <Route path="/login" element={<Login />} />
    <Route path="/quienes-somos" element={<QuienesSomos />} />
    <Route path="/terminos" element={<Terminos />} />
    <Route path="/condiciones" element={<Condiciones />} />
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="*" element={<NotFound />} />
  </Routes>
);

export default App;