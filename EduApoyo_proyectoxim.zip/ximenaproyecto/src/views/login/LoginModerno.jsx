import React from 'react';
import LoginModerno from './LoginModerno.css';;

const LoginModerno = () => {
    return(
        <div>
            <h1>Inicia sesión en tu cuenta</h1>
            <div>
                <a href="#">¿Olvidaste tu contraseña?</a>
            </div>
            <form>
                <div>
                    <label>
                        <span>Correo electrónico</span>
                    </label>
                    <input type="email"
                        id="email"
                        name="email"
                        autoCapitalize="none"
                        autoCorrect="off"
                        spellCheck="false"
                    />
                </div>
            </form>
        </div>
    );
}

export default LoginModerno;