import { Link, useNavigate } from "react-router";

export default function Login() {
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-sm bg-white p-8 rounded-2xl shadow space-y-4"
      >
        <h2 className="text-2xl font-bold text-center">Iniciar Sesión</h2>

        <label className="block text-sm font-medium">
          Correo electrónico
          <input
            type="email"
            required
            className="mt-1 w-full border rounded-lg px-3 py-2"
          />
        </label>

        <label className="block text-sm font-medium">
          Contraseña
          <input
            type="password"
            required
            className="mt-1 w-full border rounded-lg px-3 py-2"
          />
        </label>

        <button
          type="submit"
          className="w-full py-2 rounded-lg bg-indigo-600 text-white font-semibold hover:bg-indigo-700"
        >
          Entrar al Dashboard
        </button>

        <Link
          to="/"
          className="block text-center text-sm text-indigo-600 hover:underline"
        >
          ← Volver al inicio
        </Link>
      </form>
    </div>
  );
}