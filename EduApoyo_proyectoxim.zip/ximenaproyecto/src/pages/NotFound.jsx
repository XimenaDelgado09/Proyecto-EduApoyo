import { Link } from "react-router";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 text-center px-6">
      <h1 className="text-7xl font-bold text-indigo-600">404</h1>
      <h2 className="mt-4 text-2xl font-semibold text-gray-800">
        Página no encontrada
      </h2>
      <p className="mt-2 text-gray-600 max-w-md">
        La dirección que escribiste no existe o fue movida. Revisa la URL o
        regresa a la página principal.
      </p>
      <Link
        to="/"
        className="mt-6 px-5 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700"
      >
        ← Volver al inicio
      </Link>
    </div>
  );
}