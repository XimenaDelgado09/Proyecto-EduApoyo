import { Link } from "react-router";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

// 👇 CAMBIA AQUÍ los KPIs (tarjetas)
const kpis = [
  { titulo: "Estudiantes activos", valor: "1,284", cambio: "+12%", sube: true },
  { titulo: "Tutorías realizadas", valor: "326", cambio: "+8%", sube: true },
  { titulo: "Materias disponibles", valor: "18", cambio: "+2", sube: true },
  { titulo: "Tareas pendientes", valor: "47", cambio: "-5%", sube: false },
];

// 👇 CAMBIA AQUÍ los datos de la gráfica
const datos = [
  { mes: "Ene", visitas: 400 },
  { mes: "Feb", visitas: 300 },
  { mes: "Mar", visitas: 560 },
  { mes: "Abr", visitas: 480 },
  { mes: "May", visitas: 720 },
  { mes: "Jun", visitas: 650 },
  { mes: "Jul", visitas: 890 },
];

export default function Dashboard() {
  return (
    <div className="min-h-screen flex bg-gray-50 text-gray-800">
      <aside className="w-64 bg-white shadow flex flex-col p-6">
        <h2 className="text-sm font-semibold uppercase tracking-wide text-gray-400 mb-4">
          Menú principal
        </h2>

        <ul className="flex-1 space-y-2 text-sm">
          <li className="px-3 py-2 rounded-lg bg-indigo-50 text-indigo-600 font-medium">
            Inicio
          </li>
          <li className="px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100">
            Mi perfil
          </li>
          <li className="px-3 py-2 rounded-lg text-gray-600 hover:bg-gray-100">
            Configuración
          </li>
        </ul>

        <Link
          to="/"
          className="mt-6 px-3 py-2 rounded-lg text-center text-sm text-red-600 border border-red-200 hover:bg-red-50"
        >
          Cerrar sesión
        </Link>
      </aside>

      <main className="flex-1 p-10">
        <h1 className="text-3xl font-bold text-indigo-600 mb-1">
          Mi Dashboard
        </h1>
        <p className="text-gray-500 mb-8">
          ¡Bienvenido a tu panel principal! Has ingresado correctamente a tu
          plataforma.
        </p>

        {/* KPIs */}
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4 mb-8">
          {kpis.map((k) => (
            <div key={k.titulo} className="bg-white p-5 rounded-2xl shadow">
              <p className="text-sm text-gray-500">{k.titulo}</p>
              <p className="text-3xl font-bold mt-1">{k.valor}</p>
              <p
                className={`text-sm font-medium mt-1 ${
                  k.sube ? "text-green-600" : "text-red-500"
                }`}
              >
                {k.sube ? "▲" : "▼"} {k.cambio}
              </p>
            </div>
          ))}
        </div>

        {/* Gráfica */}
        <div className="bg-white p-6 rounded-2xl shadow">
          <h3 className="text-lg font-semibold mb-4">Visitas por mes</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={datos}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis dataKey="mes" />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="visitas"
                  stroke="#4f46e5"
                  strokeWidth={3}
                  dot={{ r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </main>
    </div>
  );
}