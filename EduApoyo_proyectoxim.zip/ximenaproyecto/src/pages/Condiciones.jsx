import { Link } from "react-router-dom";

export default function Condiciones() {
  return (
    <div className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow">
        <Link to="/" className="text-indigo-600 hover:underline text-sm">
          ← Volver al inicio
        </Link>

        <h1 className="text-3xl font-bold mt-4 mb-2">
          Condiciones del Servicio
        </h1>
        <p className="text-sm text-gray-500 mb-6">
          Última actualización: noviembre de 2026
        </p>

        <div className="space-y-6 text-gray-600 leading-relaxed">
          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              1. Descripción del servicio
            </h2>
            <p>
              La plataforma ofrece un panel de control para consultar y
              gestionar información de manera sencilla. Las funciones
              disponibles pueden cambiar o ampliarse con el tiempo.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              2. Requisitos de uso
            </h2>
            <p>
              Para utilizar el servicio se requiere un dispositivo con acceso a
              internet y un navegador actualizado. El usuario debe proporcionar
              información veraz al registrarse o iniciar sesión.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              3. Conducta del usuario
            </h2>
            <p>
              Queda prohibido utilizar el servicio para actividades
              fraudulentas, intentar acceder sin autorización a áreas
              restringidas o interferir con el funcionamiento normal de la
              plataforma.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              4. Disponibilidad del servicio
            </h2>
            <p>
              Trabajamos para mantener el servicio disponible de forma
              continua, aunque pueden presentarse interrupciones por
              mantenimiento, actualizaciones o causas fuera de nuestro control.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              5. Suspensión de cuentas
            </h2>
            <p>
              Nos reservamos el derecho de suspender o cancelar el acceso de
              cualquier usuario que incumpla estas condiciones o los Términos de
              Uso.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              6. Soporte
            </h2>
            <p>
              Si tienes dudas o problemas con el servicio, puedes comunicarte
              con el equipo de desarrollo a través de los medios de contacto
              indicados en la plataforma.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              7. Cambios en las condiciones
            </h2>
            <p>
              Estas condiciones pueden actualizarse en cualquier momento. Te
              recomendamos revisarlas periódicamente.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}