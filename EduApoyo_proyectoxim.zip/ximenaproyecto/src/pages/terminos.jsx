import { Link } from "react-router-dom";

export default function Terminos() {
  return (
    <div className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow">
        <Link to="/" className="text-indigo-600 hover:underline text-sm">
          ← Volver al inicio
        </Link>

        <h1 className="text-3xl font-bold mt-4 mb-2">Términos de Uso</h1>
        <p className="text-sm text-gray-500 mb-6">
          Última actualización: noviembre de 2026
        </p>

        <div className="space-y-6 text-gray-600 leading-relaxed">
          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              1. Aceptación de los términos
            </h2>
            <p>
              Al acceder y utilizar esta plataforma, aceptas cumplir con los
              presentes Términos de Uso. Si no estás de acuerdo con alguno de
              ellos, te pedimos que no utilices el sitio.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              2. Uso de la plataforma
            </h2>
            <p>
              La plataforma está destinada a fines informativos y de gestión de
              datos. El usuario se compromete a utilizarla de forma lícita, sin
              afectar el funcionamiento del sitio ni los derechos de otros
              usuarios.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              3. Cuenta de usuario
            </h2>
            <p>
              Para acceder al panel de control es necesario iniciar sesión. El
              usuario es responsable de mantener la confidencialidad de sus
              credenciales y de toda actividad realizada desde su cuenta.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              4. Propiedad intelectual
            </h2>
            <p>
              Los contenidos, diseños, logotipos y código de la plataforma son
              propiedad de sus desarrolladores. Queda prohibida su reproducción
              o distribución sin autorización previa.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              5. Privacidad de la información
            </h2>
            <p>
              Los datos proporcionados por el usuario se utilizarán únicamente
              para el funcionamiento de la plataforma y no serán compartidos con
              terceros sin su consentimiento.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              6. Limitación de responsabilidad
            </h2>
            <p>
              Hacemos nuestro mejor esfuerzo por mantener el sitio disponible y
              sin errores, pero no garantizamos un funcionamiento ininterrumpido.
              No seremos responsables por daños derivados del uso de la
              plataforma.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-gray-800 mb-1">
              7. Modificaciones
            </h2>
            <p>
              Podemos actualizar estos términos en cualquier momento. El uso
              continuado de la plataforma implica la aceptación de los cambios.
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}