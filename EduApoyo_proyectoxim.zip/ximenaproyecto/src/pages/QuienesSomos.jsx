import { Link } from "react-router-dom";

export default function QuienesSomos() {
  return (
    <div className="min-h-screen bg-gray-50 px-6 py-12">
      <div className="max-w-3xl mx-auto bg-white p-8 rounded-2xl shadow">
        <Link to="/" className="text-indigo-600 hover:underline text-sm">
          ← Volver al inicio
        </Link>

        <h1 className="text-3xl font-bold mt-4 mb-4">Quiénes Somos</h1>

        <p className="text-gray-600 leading-relaxed mb-8">
          Somos un equipo de estudiantes que está dispuesto a aprender sobre
          programación.
        </p>

        <h2 className="text-xl font-semibold mb-2">Nuestra misión</h2>
        <p className="text-gray-600 leading-relaxed mb-8">
          Crear una página web para el apoyo de los estudiantes en materias que
          se les dificulten.
        </p>

        <h2 className="text-xl font-semibold mb-2">Nuestra visión</h2>
        <p className="text-gray-600 leading-relaxed">
          Convertirnos en un equipo capaz de crear páginas web para el apoyo de
          los estudiantes.
        </p>
      </div>
    </div>
  );
}