import { Link } from "react-router";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 flex flex-col">
      <nav className="flex items-center justify-between px-8 py-4 bg-white shadow">
        <h1 className="text-xl font-bold text-indigo-600">Mi Proyecto</h1>
        <div className="flex items-center gap-6">
          <Link to="/quienes-somos" className="hover:text-indigo-600">
            Quiénes Somos
          </Link>
          <Link
            to="/login"
            className="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700"
          >
            Iniciar Sesión
          </Link>
        </div>
      </nav>

      <main className="flex-1 flex flex-col items-center justify-center text-center px-6">
        <h2 className="text-5xl font-bold mb-4">Conoce nuestra plataforma</h2>
        <p className="text-lg text-gray-600 max-w-xl">
          Bienvenido a nuestra página principal.
        </p>
      </main>

      <footer className="flex justify-center gap-6 py-6 text-sm text-gray-500 bg-white">
        <Link to="/terminos" className="hover:text-indigo-600">Términos</Link>
        <Link to="/condiciones" className="hover:text-indigo-600">Condiciones</Link>
      </footer>
    </div>
  );
}