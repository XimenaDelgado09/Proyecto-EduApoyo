export const HeroSection = () => {
  return (
    <section>
      <h1>Bienvenida a mi proyecto</h1>
      <p>Aquí va la sección principal.</p>
    </section>
  );
};

export default HeroSection;