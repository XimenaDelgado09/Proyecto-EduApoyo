const LIMITE_SEGURO = 45;

function monitorearBunker() {
    let temperaturaActual = 50;

    if (temperaturaActual > LIMITE_SEGURO) {
        let mensajeAlerta = "¡Peligro! Temperatura crítica en el sector";
        console.log(mensajeAlerta);
    }

    try {
        console.log(mensajeAlerta);
    } catch (error) {
        console.log("Fuga bloqueada con éxito:", error.message);
    }
}

console.log("--- RESULTADOS DESAFÍO 1 ---");
monitorearBunker();

const formatearRegistro = (sector, idNodo) => `[NODO-${idNodo}]: Sector ${sector} bajo sospecha.`;

const inyectarEsencia = (nombrePocion, puntosDeMana) => ({
    pocion: nombrePocion,
    mana: puntosDeMana,
    reactivo: true
});

console.log("\n--- RESULTADOS DESAFÍO 2 ---");
console.log(formatearRegistro("Alfa", 102));
console.log(inyectarEsencia("Curativa", 50));

const paqueteInterceptado = {
    emisor: "Terminal_C01",
    frecuencia: 433.92,
    encriptacion: {
        algoritmo: "AES-256",
        capas: 7,
        firmaHex: "0xAF39C2"
    },
    codigosDeAcceso: ["admin122", "oracleBunker", "akinGhost01", "rootCoyote"],
    metadata: {
        servidor: "Xihue_Core",
        timestamp: 1695709940692
    }
};

const { encriptacion: { algoritmo: metodoCifrado, capas } } = paqueteInterceptado;

const [accesoMaestro, ...clavesSecundarias] = paqueteInterceptado.codigosDeAcceso;

const paquetePurificado = {
    ...paqueteInterceptado.metadata,
    estado: "SEGURO",
    clavesSecundarias: [...clavesSecundarias]
};

console.log("\n--- RESULTADOS DESAFÍO 3 ---");
console.log("Método de cifrado:", metodoCifrado);
console.log("Capas:", capas);
console.log("Acceso maestro:", accesoMaestro);
console.log("Claves secundarias:", clavesSecundarias);
console.log("Paquete purificado:", paquetePurificado);

const nucleosEnergia = [
    { id: 101, tipo: "Tungsteno", potencia: 80, corrupto: false },
    { id: 102, tipo: "Obsidiana", potencia: 120, corrupto: true },
    { id: 103, tipo: "Silicio", potencia: 50, corrupto: false },
    { id: 104, tipo: "Cobre", potencia: 95, corrupto: false },
    { id: 105, tipo: "Plata", potencia: 110, corrupto: true }
];

const nucleosSanos = nucleosEnergia.filter(nucleo => nucleo.corrupto === false);

const nucleosPotenciados = nucleosSanos.map(nucleo => ({
    ...nucleo,
    potencia: nucleo.potencia * 1.20
}));

const energiaTotalDelBunker = nucleosPotenciados.reduce(
    (acumulador, nucleo) => acumulador + nucleo.potencia,
    0
);

console.log("\n--- RESULTADOS DESAFÍO 4 ---");
console.log("Núcleos sanos:", nucleosSanos);
console.log("Núcleos potenciados:", nucleosPotenciados);
console.log("Energía total del búnker:", energiaTotalDelBunker);